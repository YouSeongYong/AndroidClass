package com.example.fullstackapplication.tip

import android.content.Context
import androidx.recyclerview.widget.RecyclerView

class ListAdapter(val context:Context, val listActivity:ArrayList<ListVO>):
    RecyclerView.Adapter<ListAdapter.ViewHolder>() {
}