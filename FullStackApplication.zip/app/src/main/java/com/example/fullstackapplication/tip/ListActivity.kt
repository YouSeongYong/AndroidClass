package com.example.fullstackapplication.tip

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.fullstackapplication.R

class ListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        //TextView
        //RecyclerView ---> Adapter, data(VO), template(xml)

        //Adapter ---> ListAdapter
        // data(VO) ---> ListVO
        // template ---> layout폴더에 list_template.xml

        // 이미지의 id(Int), title (String) ---> VO로 묶어야할 데이터
        // 3-4개 정도 임의로 만들어 놓기

        //template.xml -> imageView하나, TextView, 북마크 Image View

        //Adapter : 리사이클러뷰를 상속받게 만들어주세요
        // ViewHolder, onCreateView, OnbindView, getItemCount
        // 단 GridLayoutManager를 사용해서 두줄로 쌓이게 만들자

    }
}