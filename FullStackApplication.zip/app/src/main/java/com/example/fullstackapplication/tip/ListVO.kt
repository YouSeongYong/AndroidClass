package com.example.fullstackapplication.tip

class ListVO() {
}